
document.getElementById('loginForm').addEventListener('submit', function(event) {
event.preventDefault();

var username = document.getElementById('username').value;
var password = document.getElementById('password').value;

if (username === 'admin' && password === '1234') {
    document.getElementById('message').textContent = 
    'login efetuado com sucesso!';
    window.location = 'aula34.html'

}
else{
    document.getElementById('message').textContent = 
    'usuário ou senha incorretos!';
}

})


